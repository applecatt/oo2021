public enum ItemType {
    MISC, WEAP, ARMOR, GOLD
}