public enum GameCharacterType {
    WIZARD, WARRIOR, RANGER
  }